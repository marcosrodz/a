<?php 

require_once("menu.php");

require_once("conexao.php");
require_once("verifica_usuario_logado.php");
require_once("cabecalho.php");
